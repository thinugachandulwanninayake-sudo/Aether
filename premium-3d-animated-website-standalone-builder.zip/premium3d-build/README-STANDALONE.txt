PREMIUM 3D WEBSITE — STANDALONE HTML

The source project already uses vite-plugin-singlefile. Follow these steps on your Mac:

1. Extract this ZIP.
2. Make sure Node.js LTS is installed: https://nodejs.org/
3. Double-click build-standalone.command.
   - If macOS blocks it, right-click the file and choose Open.
   - The first build needs an internet connection to download dependencies.
4. When it says Build complete, open the dist folder and double-click index.html.

The standalone file is generated at dist/index.html. Keep the whole extracted project folder
until you have generated the file. Some browser security restrictions or remote image/font
services can still require internet access; the JavaScript and CSS bundles are inlined by Vite.

If you prefer Terminal, run these commands from the project folder:
  npm install
  npm run build
