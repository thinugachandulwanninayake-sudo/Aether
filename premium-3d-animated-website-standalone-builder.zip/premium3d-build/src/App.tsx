import { useCallback, useEffect, useState } from 'react';
import { AnimatePresence, motion, useScroll, useSpring } from 'framer-motion';
import Loader from './components/Loader';
import CustomCursor from './components/CustomCursor';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Intro from './components/Intro';
import Showcase from './components/Showcase';
import Features from './components/Features';
import Gallery from './components/Gallery';
import HowItWorks from './components/HowItWorks';
import Stats from './components/Stats';
import Testimonials from './components/Testimonials';
import CTA from './components/CTA';
import Footer from './components/Footer';

export default function App() {
  const [loading, setLoading] = useState(true);
  const [loaded, setLoaded] = useState(false);
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 90, damping: 22 });

  const done = useCallback(() => {
    setLoading(false);
    setTimeout(() => setLoaded(true), 150);
  }, []);

  useEffect(() => {
    document.body.style.overflow = loading ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [loading]);

  // safety: never trap user on loader
  useEffect(() => {
    const t = setTimeout(() => {
      setLoading(false);
      setLoaded(true);
    }, 5000);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className="theme-paper relative min-h-screen selection:bg-indigo-200">
      <CustomCursor />
      <div className="noise-overlay" />

      {/* scroll progress */}
      <motion.div
        className="scroll-progress fixed inset-x-0 top-0 z-[130] h-[2px] origin-left"
        style={{
          scaleX: progress,
          background: 'linear-gradient(90deg,#4f7cff,#8b5cf6,#22d3ee)',
          boxShadow: '0 0 12px rgba(139,92,246,.7)',
        }}
      />

      <AnimatePresence>{loading && <Loader onDone={done} />}</AnimatePresence>

      <Navbar loaded={loaded} />

      <main>
        <Hero loaded={loaded} />
        <Intro />
        <Showcase />
        <Features />
        <Gallery />
        <HowItWorks />
        <Stats />
        <Testimonials />
        <CTA />
      </main>

      <Footer />
    </div>
  );
}
