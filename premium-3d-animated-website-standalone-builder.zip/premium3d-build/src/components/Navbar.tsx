import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ChevronDown, ArrowUpRight, Boxes, Sparkles, Cpu, Layers } from 'lucide-react';

const LINKS = [
  { id: 'showcase', label: 'Showcase' },
  { id: 'features', label: 'Features' },
  { id: 'gallery', label: 'Gallery' },
  { id: 'process', label: 'Process' },
  { id: 'testimonials', label: 'Clients' },
];

const DROPDOWN = [
  { icon: Boxes, title: 'Spatial Engine', desc: 'Real-time WebGL rendering core' },
  { icon: Cpu, title: 'Neural Physics', desc: 'GPU-accelerated simulation' },
  { icon: Layers, title: 'Material Lab', desc: 'Procedural PBR authoring' },
  { icon: Sparkles, title: 'Aether Cloud', desc: 'One-click global deployment' },
];

export default function Navbar({ loaded }: { loaded: boolean }) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [drop, setDrop] = useState(false);
  const [active, setActive] = useState('');

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 40);
      const ids = ['showcase', 'features', 'gallery', 'process', 'testimonials'];
      let cur = '';
      for (const id of ids) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top < window.innerHeight * 0.4) cur = id;
      }
      setActive(cur);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const go = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={loaded ? { y: 0, opacity: 1 } : {}}
      transition={{ duration: 0.9, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
      className="fixed inset-x-0 top-0 z-[120] flex justify-center px-3 pt-3 md:px-6 md:pt-5"
    >
      <nav
        className={`flex w-full max-w-6xl items-center justify-between rounded-2xl px-4 py-3 transition-all duration-500 md:px-6 ${
          scrolled ? 'glass-strong shadow-[0_12px_50px_-12px_rgba(0,0,0,0.8)]' : 'border border-transparent bg-transparent'
        }`}
      >
        {/* logo */}
        <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-2.5" data-hover>
          <div className="flex h-9 w-9 items-center justify-center rounded-xl"
            style={{ background: 'linear-gradient(135deg,#4f7cff,#8b5cf6 60%,#22d3ee)', boxShadow: '0 0 24px rgba(124,92,255,.45)' }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L22 12L12 22L2 12L12 2Z" stroke="white" strokeWidth="1.8" />
              <circle cx="12" cy="12" r="3.2" fill="white" />
            </svg>
          </div>
          <span className="font-display text-sm font-bold tracking-[0.3em] text-white">AETHER</span>
        </button>

        {/* desktop links */}
        <div className="hidden items-center gap-7 lg:flex">
          <div className="relative" onMouseEnter={() => setDrop(true)} onMouseLeave={() => setDrop(false)}>
            <button className="flex items-center gap-1 text-[13px] font-medium text-white/70 transition hover:text-white" data-hover>
              Platform <ChevronDown size={14} className={`transition-transform duration-300 ${drop ? 'rotate-180' : ''}`} />
            </button>
            <AnimatePresence>
              {drop && (
                <motion.div
                  initial={{ opacity: 0, y: 12, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 8, scale: 0.97 }}
                  transition={{ duration: 0.25, ease: 'easeOut' }}
                  className="glass-strong absolute left-1/2 top-full mt-3 w-[380px] -translate-x-1/2 rounded-2xl p-2"
                >
                  {DROPDOWN.map((d) => (
                    <button
                      key={d.title}
                      onClick={() => { setDrop(false); go('features'); }}
                      className="group flex w-full items-start gap-3 rounded-xl p-3 text-left transition hover:bg-white/[0.06]"
                    >
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-indigo-500/25 to-cyan-400/15 text-cyan-300 ring-1 ring-white/10">
                        <d.icon size={17} />
                      </div>
                      <div>
                        <div className="text-[13px] font-semibold text-white">{d.title}</div>
                        <div className="text-xs text-white/50">{d.desc}</div>
                      </div>
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          {LINKS.map((l) => (
            <button
              key={l.id}
              onClick={() => go(l.id)}
              data-hover
              className={`link-underline text-[13px] font-medium transition ${active === l.id ? 'active text-white' : 'text-white/65 hover:text-white'}`}
            >
              {l.label}
            </button>
          ))}
        </div>

        <div className="hidden items-center gap-3 lg:flex">
          <button onClick={() => go('cta')} data-hover className="text-[13px] font-medium text-white/65 transition hover:text-white">
            Sign in
          </button>
          <button
            onClick={() => go('cta')}
            data-hover
            className="group flex items-center gap-1.5 rounded-full px-5 py-2.5 text-[13px] font-semibold text-white transition-transform active:scale-95"
            style={{ background: 'linear-gradient(135deg,#4f7cff,#8b5cf6 60%,#22d3ee)', boxShadow: '0 4px 28px -4px rgba(99,102,241,.6)' }}
          >
            Get access
            <ArrowUpRight size={15} className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </button>
        </div>

        {/* mobile toggle */}
        <button onClick={() => setOpen(!open)} className="flex h-10 w-10 items-center justify-center rounded-xl glass lg:hidden" aria-label="Menu">
          {open ? <X size={19} /> : <Menu size={19} />}
        </button>
      </nav>

      {/* mobile panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -12, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -12, scale: 0.98 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="glass-strong fixed inset-x-3 top-[76px] rounded-2xl p-3 lg:hidden"
          >
            {[ { id: 'top', label: 'Home' }, ...LINKS].map((l, i) => (
              <motion.button
                key={l.id}
                initial={{ opacity: 0, x: -14 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 * i }}
                onClick={() => (l.id === 'top' ? window.scrollTo({ top: 0, behavior: 'smooth' }) : go(l.id))}
                className="flex w-full items-center justify-between rounded-xl px-4 py-3.5 text-left text-[15px] font-medium text-white/80 transition hover:bg-white/[0.06] hover:text-white"
              >
                {l.label}
                <ArrowUpRight size={16} className="text-white/30" />
              </motion.button>
            ))}
            <button
              onClick={() => go('cta')}
              className="mt-2 w-full rounded-xl py-3.5 text-sm font-semibold text-white"
              style={{ background: 'linear-gradient(135deg,#4f7cff,#8b5cf6 60%,#22d3ee)' }}
            >
              Get early access
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
