import React, { useRef, useState, useCallback } from 'react';
import { motion, useInView } from 'framer-motion';

/* ---------- Magnetic wrapper ---------- */
export function Magnetic({
  children,
  strength = 24,
  className = '',
}: {
  children: React.ReactNode;
  strength?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState({ x: 0, y: 0 });

  const onMove = useCallback(
    (e: React.MouseEvent) => {
      if (!ref.current) return;
      const r = ref.current.getBoundingClientRect();
      const x = e.clientX - (r.left + r.width / 2);
      const y = e.clientY - (r.top + r.height / 2);
      setPos({ x: (x / r.width) * strength, y: (y / r.height) * strength });
    },
    [strength]
  );

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      onMouseLeave={() => setPos({ x: 0, y: 0 })}
      animate={{ x: pos.x, y: pos.y }}
      transition={{ type: 'spring', stiffness: 180, damping: 14, mass: 0.4 }}
      className={`inline-block ${className}`}
    >
      {children}
    </motion.div>
  );
}

/* ---------- Staggered word reveal ---------- */
export function RevealText({
  text,
  className = '',
  delay = 0,
  as: Tag = 'span',
  stagger = 0.045,
}: {
  text: string;
  className?: string;
  delay?: number;
  as?: any;
  stagger?: number;
}) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-12% 0px' });
  const words = text.split(' ');
  return (
    <Tag ref={ref} className={className} style={{ display: 'inline-block' }}>
      {words.map((w, i) => (
        <span key={i} className="inline-block overflow-hidden pb-[0.12em] -mb-[0.12em] align-bottom">
          <motion.span
            className="inline-block will-change-transform"
            initial={{ y: '115%', opacity: 0, filter: 'blur(6px)' }}
            animate={inView ? { y: '0%', opacity: 1, filter: 'blur(0px)' } : {}}
            transition={{ duration: 0.9, delay: delay + i * stagger, ease: [0.22, 1, 0.36, 1] }}
          >
            {w}
            {i < words.length - 1 ? '\u00A0' : ''}
          </motion.span>
        </span>
      ))}
    </Tag>
  );
}

/* ---------- Fade up on scroll ---------- */
export function FadeUp({
  children,
  delay = 0,
  y = 36,
  className = '',
  once = true,
}: {
  children: React.ReactNode;
  delay?: number;
  y?: number;
  className?: string;
  once?: boolean;
}) {
  const ref = useRef(null);
  const inView = useInView(ref, { once, margin: '-10% 0px' });
  return (
    <motion.div
      ref={ref}
      className={className}
      initial={{ opacity: 0, y, filter: 'blur(8px)' }}
      animate={inView ? { opacity: 1, y: 0, filter: 'blur(0px)' } : {}}
      transition={{ duration: 0.9, delay, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
}

/* ---------- 3D Tilt card ---------- */
export function TiltCard({
  children,
  className = '',
  max = 10,
  glare = true,
}: {
  children: React.ReactNode;
  className?: string;
  max?: number;
  glare?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [t, setT] = useState({ rx: 0, ry: 0, gx: 50, gy: 50, hovering: false });

  const handle = (e: React.MouseEvent) => {
    if (!ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width;
    const py = (e.clientY - r.top) / r.height;
    setT({
      rx: (0.5 - py) * max * 2,
      ry: (px - 0.5) * max * 2,
      gx: px * 100,
      gy: py * 100,
      hovering: true,
    });
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={handle}
      onMouseLeave={() => setT((s) => ({ ...s, rx: 0, ry: 0, hovering: false }))}
      animate={{ rotateX: t.rx, rotateY: t.ry, scale: t.hovering ? 1.02 : 1 }}
      transition={{ type: 'spring', stiffness: 260, damping: 22 }}
      style={{ transformStyle: 'preserve-3d', perspective: 900 }}
      className={`relative ${className}`}
    >
      {children}
      {glare && (
        <div
          className="pointer-events-none absolute inset-0 rounded-[inherit] transition-opacity duration-300"
          style={{
            opacity: t.hovering ? 1 : 0,
            background: `radial-gradient(circle at ${t.gx}% ${t.gy}%, rgba(139,92,246,0.16), transparent 55%)`,
          }}
        />
      )}
    </motion.div>
  );
}

/* ---------- Section eyebrow + heading ---------- */
export function SectionHeading({
  eyebrow,
  title,
  sub,
  align = 'center',
}: {
  eyebrow: string;
  title: string;
  sub?: string;
  align?: 'center' | 'left';
}) {
  const a = align === 'center' ? 'text-center mx-auto' : 'text-left';
  return (
    <div className={`max-w-3xl ${a}`}>
      <FadeUp>
        <div
          className={`inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-[11px] font-mono uppercase tracking-[0.22em] text-cyan-200/90 ${
            align === 'center' ? '' : ''
          }`}
        >
          <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-r from-blue-400 to-cyan-300 animate-pulse-glow" />
          {eyebrow}
        </div>
      </FadeUp>
      <RevealText
        text={title}
        as="h2"
        delay={0.1}
        className={`font-display mt-5 text-4xl md:text-5xl lg:text-6xl font-semibold leading-[1.04] tracking-tight text-white ${align === 'center' ? '' : ''}`}
      />
      {sub && (
        <FadeUp delay={0.25}>
          <p className="mt-5 text-base md:text-lg leading-relaxed text-white/55">{sub}</p>
        </FadeUp>
      )}
    </div>
  );
}

/* ---------- Primary / Ghost buttons ---------- */
export function GlowButton({
  children,
  onClick,
  variant = 'primary',
  className = '',
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'ghost';
  className?: string;
}) {
  if (variant === 'ghost') {
    return (
      <Magnetic>
        <button
          onClick={onClick}
          className={`group relative overflow-hidden rounded-full glass px-7 py-3.5 text-sm font-medium text-white/90 transition-all duration-300 hover:border-white/25 hover:bg-white/[0.07] active:scale-[0.97] ${className}`}
        >
          <span className="relative z-10 inline-flex items-center gap-2">{children}</span>
        </button>
      </Magnetic>
    );
  }
  return (
    <Magnetic>
      <button
        onClick={onClick}
        className={`group relative overflow-hidden rounded-full px-7 py-3.5 text-sm font-semibold text-white transition-transform duration-300 active:scale-[0.97] ${className}`}
        style={{
          background: 'linear-gradient(135deg, #4f7cff 0%, #7c5cff 45%, #22d3ee 130%)',
          boxShadow: '0 8px 40px -6px rgba(99,102,241,0.55), inset 0 1px 0 rgba(255,255,255,0.25)',
        }}
      >
        <span className="absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
          style={{ background: 'linear-gradient(135deg, #6d94ff 0%, #8b5cf6 50%, #38e0f8 130%)' }} />
        <span className="relative z-10 inline-flex items-center gap-2">{children}</span>
      </button>
    </Magnetic>
  );
}
