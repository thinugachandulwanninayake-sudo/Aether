import { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Environment, Lightformer, ContactShadows, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';

export const VARIANTS = [
  { name: 'Quantum Core', desc: 'Torus-knot reactor with iridescent glass shell and emissive plasma lattice.', color: '#8b5cf6' },
  { name: 'Neural Lattice', desc: 'Icosahedral neural mesh — 2,048 nodes simulated live on the GPU.', color: '#22d3ee' },
  { name: 'Flux Rings', desc: 'Tri-axial gyroscope in polished chrome with magnetic levitation.', color: '#4f7cff' },
];

function Model({ variant, wireframe, autoRotate }: { variant: number; wireframe: boolean; autoRotate: boolean }) {
  const g = useRef<THREE.Group>(null);
  const inner = useRef<THREE.Group>(null);
  const scale = useRef(0.01);

  useFrame((state, dt) => {
    scale.current = THREE.MathUtils.lerp(scale.current, 1, 1 - Math.pow(0.001, dt));
    if (g.current) {
      g.current.scale.setScalar(scale.current);
      if (autoRotate) {
        g.current.rotation.y += dt * 0.45;
        g.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.3) * 0.15;
      }
    }
    if (inner.current) inner.current.rotation.y -= dt * 0.7;
  });

  return (
    <group ref={g}>
      {variant === 0 && (
        <>
          <mesh>
            <torusKnotGeometry args={[0.85, 0.28, 220, 36]} />
            <meshPhysicalMaterial
              color="#12121f" metalness={0.2} roughness={0.08}
              transmission={1} thickness={1.4} ior={1.5}
              clearcoat={1} iridescence={0.8} iridescenceIOR={1.4}
              envMapIntensity={1.8} wireframe={wireframe}
            />
          </mesh>
          <group ref={inner}>
            <mesh scale={1.001}>
              <torusKnotGeometry args={[0.85, 0.29, 90, 12]} />
              <meshBasicMaterial color="#a78bfa" wireframe transparent opacity={0.22} />
            </mesh>
            <pointLight intensity={6} distance={8} color="#8b5cf6" />
          </group>
          <mesh rotation={[Math.PI / 2.2, 0, 0]}>
            <torusGeometry args={[1.9, 0.012, 12, 160]} />
            <meshBasicMaterial color="#8b5cf6" transparent opacity={0.7} />
          </mesh>
        </>
      )}

      {variant === 1 && (
        <>
          <mesh>
            <icosahedronGeometry args={[1.25, 3]} />
            <meshPhysicalMaterial
              color="#0a1622" metalness={0.35} roughness={0.15}
              transmission={0.9} thickness={1.2} ior={1.4}
              clearcoat={1} envMapIntensity={1.6} wireframe={wireframe}
            />
          </mesh>
          <group ref={inner}>
            <mesh scale={1.005}>
              <icosahedronGeometry args={[1.25, 2]} />
              <meshBasicMaterial color="#22d3ee" wireframe transparent opacity={0.3} />
            </mesh>
            <mesh>
              <icosahedronGeometry args={[0.45, 1]} />
              <meshStandardMaterial color="#06121c" emissive="#22d3ee" emissiveIntensity={2.6} roughness={0.3} />
            </mesh>
            <pointLight intensity={6} distance={8} color="#22d3ee" />
          </group>
          <mesh rotation={[Math.PI / 2.5, 0.4, 0]}>
            <torusGeometry args={[2.0, 0.01, 12, 160]} />
            <meshBasicMaterial color="#22d3ee" transparent opacity={0.55} />
          </mesh>
        </>
      )}

      {variant === 2 && (
        <>
          <mesh>
            <sphereGeometry args={[0.7, 64, 64]} />
            <meshStandardMaterial color="#cfd6ff" metalness={1} roughness={0.12} envMapIntensity={2} wireframe={wireframe} />
          </mesh>
          <group ref={inner}>
            {[0, 1, 2].map((i) => (
              <mesh key={i} rotation={[(i * Math.PI) / 3, (i * Math.PI) / 4, 0]}>
                <torusGeometry args={[1.35 + i * 0.22, 0.045 - i * 0.008, 24, 140]} />
                <meshStandardMaterial
                  color={i === 1 ? '#8b5cf6' : '#9fb2ff'}
                  metalness={1} roughness={0.18}
                  emissive={i === 1 ? '#4f7cff' : '#000000'} emissiveIntensity={i === 1 ? 0.7 : 0}
                />
              </mesh>
            ))}
            <pointLight intensity={5} distance={8} color="#4f7cff" />
          </group>
        </>
      )}
    </group>
  );
}

export default function ShowcaseScene({
  variant,
  wireframe,
  autoRotate,
}: {
  variant: number;
  wireframe: boolean;
  autoRotate: boolean;
}) {
  return (
    <Canvas
      dpr={[1, 1.8]}
      camera={{ position: [0, 0.6, 5.2], fov: 40 }}
      gl={{ antialias: true, alpha: true }}
    >
      <Suspense fallback={null}>
        <ambientLight intensity={0.3} />
        <spotLight position={[6, 6, 4]} intensity={1.2} color="#aebaff" angle={0.5} penumbra={1} />
        <pointLight position={[-5, -2, 3]} intensity={8} color={VARIANTS[variant].color} distance={16} />
        <pointLight position={[4, 3, -3]} intensity={6} color="#22d3ee" distance={14} />
        <Model key={variant} variant={variant} wireframe={wireframe} autoRotate={autoRotate} />
        <ContactShadows position={[0, -2.2, 0]} opacity={0.6} scale={10} blur={2.4} far={4} />
        <OrbitControls
          enableZoom={false}
          enablePan={false}
          minPolarAngle={Math.PI / 3.2}
          maxPolarAngle={Math.PI / 1.7}
          autoRotate={false}
        />
        <Environment resolution={256}>
          <group rotation={[-Math.PI / 3, 0, 0]}>
            <Lightformer form="circle" intensity={5} position={[0, 5, -9]} scale={2} color="#aebaff" />
            <Lightformer intensity={2.2} rotation-y={Math.PI / 2} position={[-5, 1, -1]} scale={[20, 0.6, 1]} color="#22d3ee" />
            <Lightformer intensity={2.2} rotation-y={-Math.PI / 2} position={[5, 1, 0]} scale={[20, 0.8, 1]} color="#8b5cf6" />
          </group>
        </Environment>
      </Suspense>
    </Canvas>
  );
}
