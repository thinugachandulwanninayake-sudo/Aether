import { lazy, Suspense, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Rotate3d, Grid3x3, Pause, Play, Move3d, MousePointerClick } from 'lucide-react';
import { SectionHeading, Magnetic } from './ui';
import { VARIANTS } from './ShowcaseScene';

const ShowcaseScene = lazy(() => import('./ShowcaseScene'));

export default function Showcase() {
  const [variant, setVariant] = useState(0);
  const [wireframe, setWireframe] = useState(false);
  const [spin, setSpin] = useState(true);

  return (
    <section id="showcase" className="relative overflow-hidden px-5 py-24 md:py-36">
      <div className="pointer-events-none absolute right-0 top-20 h-[420px] w-[420px] rounded-full bg-indigo-600/10 blur-[130px]" />
      <div className="pointer-events-none absolute left-0 bottom-0 h-[380px] w-[380px] rounded-full bg-cyan-500/[0.07] blur-[130px]" />

      <div className="relative mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Interactive showcase"
          title="Touch the future. Literally."
          sub="Every model below renders live in your browser. Drag to orbit, switch artifacts, and inspect the raw geometry."
        />

        {/* variant tabs */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
          {VARIANTS.map((v, i) => (
            <Magnetic key={v.name} strength={12}>
              <button
                onClick={() => setVariant(i)}
                data-hover
                className={`relative rounded-full px-6 py-3 text-sm font-medium transition-all duration-300 ${
                  variant === i ? 'text-white' : 'glass text-white/55 hover:text-white'
                }`}
                style={variant === i ? { background: 'linear-gradient(135deg,#4f7cff,#8b5cf6)', boxShadow: `0 6px 30px -6px ${v.color}` } : {}}
              >
                {v.name}
              </button>
            </Magnetic>
          ))}
        </div>

        {/* 3D viewport */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className="gradient-border relative mt-8 overflow-hidden rounded-[2rem]"
        >
          <div className="grid-bg absolute inset-0 opacity-60" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_55%_50%_at_50%_45%,rgba(99,102,241,0.14),transparent_70%)]" />

          {/* HUD top */}
          <div className="absolute inset-x-0 top-0 z-10 flex items-center justify-between p-5 md:p-6">
            <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.22em] text-white/45">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse-glow" />
              Live viewport
            </div>
            <AnimatePresence mode="wait">
              <motion.div
                key={variant}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                className="font-mono text-[10px] uppercase tracking-[0.22em] text-white/45"
              >
                {VARIANTS[variant].name} · 60fps
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Canvas */}
          <div className="relative h-[420px] md:h-[540px]">
            <Suspense
              fallback={
                <div className="flex h-full items-center justify-center">
                  <div className="h-10 w-10 animate-spin rounded-full border-2 border-violet-400/30 border-t-violet-400" />
                </div>
              }
            >
              <ShowcaseScene variant={variant} wireframe={wireframe} autoRotate={spin} />
            </Suspense>
          </div>

          {/* description + controls */}
          <div className="relative z-10 flex flex-col gap-5 border-t border-white/[0.07] bg-black/40 p-5 backdrop-blur-xl md:flex-row md:items-center md:justify-between md:p-6">
            <AnimatePresence mode="wait">
              <motion.p
                key={variant}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.35 }}
                className="max-w-md text-sm leading-relaxed text-white/55"
              >
                <span className="font-semibold text-white">{VARIANTS[variant].name} — </span>
                {VARIANTS[variant].desc}
              </motion.p>
            </AnimatePresence>
            <div className="flex flex-wrap items-center gap-2.5">
              <ControlBtn active={spin} onClick={() => setSpin(!spin)} icon={spin ? <Pause size={14} /> : <Play size={14} />} label={spin ? 'Pause spin' : 'Auto spin'} />
              <ControlBtn active={wireframe} onClick={() => setWireframe(!wireframe)} icon={<Grid3x3 size={14} />} label="Wireframe" />
              <div className="hidden items-center gap-2 rounded-full glass px-4 py-2.5 font-mono text-[10px] uppercase tracking-widest text-white/40 md:flex">
                <Move3d size={13} /> Drag to orbit
              </div>
              <div className="flex items-center gap-2 rounded-full glass px-4 py-2.5 font-mono text-[10px] uppercase tracking-widest text-white/40 md:hidden">
                <MousePointerClick size={13} /> Swipe to orbit
              </div>
            </div>
          </div>

          <Rotate3d size={15} className="absolute bottom-40 right-6 hidden text-white/25 md:block" />
        </motion.div>
      </div>
    </section>
  );
}

function ControlBtn({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      data-hover
      className={`flex items-center gap-2 rounded-full px-4 py-2.5 text-xs font-medium transition-all duration-300 active:scale-95 ${
        active
          ? 'text-white'
          : 'glass text-white/60 hover:text-white'
      }`}
      style={active ? { background: 'linear-gradient(135deg,#4f7cff,#8b5cf6)', boxShadow: '0 4px 20px -4px rgba(99,102,241,.6)' } : {}}
    >
      {icon} {label}
    </button>
  );
}
