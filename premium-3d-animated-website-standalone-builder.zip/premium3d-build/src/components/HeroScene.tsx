import { Suspense, useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Float, Environment, Lightformer, ContactShadows } from '@react-three/drei';
import * as THREE from 'three';

/* ---------- Particle field ---------- */
function Particles({ count = 1200 }: { count?: number }) {
  const ref = useRef<THREE.Points>(null);
  const { positions, colors } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const c1 = new THREE.Color('#4f7cff');
    const c2 = new THREE.Color('#8b5cf6');
    const c3 = new THREE.Color('#22d3ee');
    for (let i = 0; i < count; i++) {
      const r = 4 + Math.random() * 14;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = (Math.random() - 0.5) * 14;
      positions[i * 3 + 2] = r * Math.sin(phi) * Math.sin(theta);
      const pick = Math.random();
      const c = pick < 0.4 ? c1 : pick < 0.75 ? c2 : c3;
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }
    return { positions, colors };
  }, [count]);

  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.elapsedTime;
    ref.current.rotation.y = t * 0.02;
    ref.current.rotation.x = Math.sin(t * 0.05) * 0.08;
    // subtle pointer drift
    const px = state.pointer.x * 0.4;
    const py = state.pointer.y * 0.4;
    ref.current.position.x += (px - ref.current.position.x) * 0.02;
    ref.current.position.y += (py - ref.current.position.y) * 0.02;
  });

  return (
    <points ref={ref}>
      <bufferGeometry>
        <bufferAttribute attach="attributes-position" args={[positions, 3]} />
        <bufferAttribute attach="attributes-color" args={[colors, 3]} />
      </bufferGeometry>
      <pointsMaterial
        size={0.045}
        vertexColors
        transparent
        opacity={0.75}
        sizeAttenuation
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

/* ---------- Central artifact ---------- */
function Artifact() {
  const core = useRef<THREE.Mesh>(null);
  const shell = useRef<THREE.Mesh>(null);
  const ring1 = useRef<THREE.Mesh>(null);
  const ring2 = useRef<THREE.Mesh>(null);
  const ring3 = useRef<THREE.Mesh>(null);
  const orbit = useRef<THREE.Group>(null);
  const group = useRef<THREE.Group>(null);
  const reduced = typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const px = state.pointer.x;
    const py = state.pointer.y;
    const scroll = Math.min(1, window.scrollY / window.innerHeight);

    if (group.current) {
      group.current.position.y = -scroll * 4.2;
      group.current.rotation.y += ((px * 0.35 + scroll * 1.4) - group.current.rotation.y) * 0.03;
      group.current.rotation.x += ((py * -0.22) - group.current.rotation.x) * 0.03;
    }
    if (core.current && !reduced) {
      core.current.rotation.y = t * 0.25;
      core.current.rotation.x = t * 0.12;
      const s = 1 + Math.sin(t * 1.4) * 0.025;
      core.current.scale.setScalar(s);
    }
    if (shell.current) shell.current.rotation.y = -t * 0.08;
    if (ring1.current) {
      ring1.current.rotation.x = Math.PI / 2.4 + Math.sin(t * 0.3) * 0.12;
      ring1.current.rotation.z = t * 0.18;
    }
    if (ring2.current) {
      ring2.current.rotation.x = Math.PI / 1.8 + Math.cos(t * 0.25) * 0.1;
      ring2.current.rotation.z = -t * 0.14;
    }
    if (ring3.current) ring3.current.rotation.z = t * 0.1;
    if (orbit.current) orbit.current.rotation.y = t * 0.35;
  });

  return (
    <group ref={group}>
      <Float speed={1.6} rotationIntensity={0.25} floatIntensity={0.9}>
        {/* Glass core */}
        <mesh ref={core}>
          <icosahedronGeometry args={[1.35, 1]} />
          <meshPhysicalMaterial
            color="#0d0d18"
            metalness={0.1}
            roughness={0.05}
            transmission={1}
            thickness={1.6}
            ior={1.45}
            clearcoat={1}
            clearcoatRoughness={0.1}
            iridescence={0.7}
            iridescenceIOR={1.3}
            envMapIntensity={1.6}
          />
        </mesh>

        {/* Inner glowing core */}
        <mesh>
          <icosahedronGeometry args={[0.52, 1]} />
          <meshStandardMaterial color="#1a1040" emissive="#7c3aed" emissiveIntensity={2.4} roughness={0.3} metalness={0.6} />
        </mesh>
        <mesh scale={0.72}>
          <icosahedronGeometry args={[0.52, 1]} />
          <meshBasicMaterial color="#22d3ee" wireframe transparent opacity={0.35} />
        </mesh>

        {/* Wire shell */}
        <mesh ref={shell} scale={1.42}>
          <icosahedronGeometry args={[1.35, 1]} />
          <meshBasicMaterial color="#6d7cff" wireframe transparent opacity={0.14} />
        </mesh>

        {/* Orbit rings */}
        <mesh ref={ring1}>
          <torusGeometry args={[2.25, 0.014, 16, 180]} />
          <meshBasicMaterial color="#60a5fa" transparent opacity={0.85} />
        </mesh>
        <mesh ref={ring2}>
          <torusGeometry args={[2.65, 0.01, 16, 180]} />
          <meshBasicMaterial color="#8b5cf6" transparent opacity={0.6} />
        </mesh>
        <mesh ref={ring3} rotation={[Math.PI / 2.1, 0, 0]}>
          <torusGeometry args={[3.0, 0.006, 12, 200]} />
          <meshBasicMaterial color="#22d3ee" transparent opacity={0.4} />
        </mesh>

        {/* Orbiting satellites */}
        <group ref={orbit}>
          {[0, 1, 2].map((i) => {
            const a = (i / 3) * Math.PI * 2;
            return (
              <mesh key={i} position={[Math.cos(a) * 2.25, 0.25 * Math.sin(a * 2), Math.sin(a) * 2.25]}>
                <sphereGeometry args={[0.055, 24, 24]} />
                <meshStandardMaterial color="#fff" emissive={i === 1 ? '#22d3ee' : '#8b5cf6'} emissiveIntensity={3.5} />
              </mesh>
            );
          })}
        </group>

        {/* Halo disc */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.15, 0]}>
          <ringGeometry args={[1.1, 1.14, 90]} />
          <meshBasicMaterial color="#4f7cff" transparent opacity={0.5} side={THREE.DoubleSide} />
        </mesh>
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -2.16, 0]}>
          <ringGeometry args={[1.5, 1.52, 90]} />
          <meshBasicMaterial color="#22d3ee" transparent opacity={0.25} side={THREE.DoubleSide} />
        </mesh>
      </Float>
    </group>
  );
}

/* ---------- Camera rig ---------- */
function Rig() {
  const { camera, pointer } = useThree();
  const target = useMemo(() => new THREE.Vector3(), []);
  useFrame(() => {
    const scroll = Math.min(1, window.scrollY / window.innerHeight);
    target.set(pointer.x * 0.7, 0.4 + pointer.y * 0.45 - scroll * 1.2, 7.2 - scroll * 1.4);
    camera.position.lerp(target, 0.035);
    camera.lookAt(0, -scroll * 3.4, 0);
  });
  return null;
}

export default function HeroScene() {
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;
  return (
    <Canvas
      dpr={[1, isMobile ? 1.5 : 1.9]}
      camera={{ position: [0, 0.4, 7.2], fov: 42 }}
      gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      style={{ background: 'transparent' }}
    >
      <Suspense fallback={null}>
        <ambientLight intensity={0.25} />
        <spotLight position={[8, 8, 6]} angle={0.4} penumbra={1} intensity={1.4} color="#8b9dff" />
        <pointLight position={[-7, -3, 4]} intensity={14} color="#7c3aed" distance={20} />
        <pointLight position={[6, -4, 3]} intensity={10} color="#22d3ee" distance={18} />
        <pointLight position={[0, 5, -4]} intensity={8} color="#4f7cff" distance={16} />

        <Artifact />
        <Particles count={isMobile ? 550 : 1300} />
        <ContactShadows position={[0, -3.1, 0]} opacity={0.55} scale={12} blur={2.6} far={4} color="#000000" />
        <Rig />
        <Environment resolution={256}>
          <group rotation={[-Math.PI / 3, 0, 0]}>
            <Lightformer form="circle" intensity={5} rotation-x={Math.PI / 2} position={[0, 5, -9]} scale={2} color="#8b9dff" />
            <Lightformer intensity={2.5} rotation-y={Math.PI / 2} position={[-5, 1, -1]} scale={[20, 0.6, 1]} color="#22d3ee" />
            <Lightformer intensity={2.5} rotation-y={-Math.PI / 2} position={[5, 1, 0]} scale={[20, 0.8, 1]} color="#8b5cf6" />
            <Lightformer intensity={1.2} position={[0, 5, 5]} scale={[10, 2, 1]} color="#ffffff" />
          </group>
        </Environment>
      </Suspense>
    </Canvas>
  );
}
