import { useLayoutEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowLeft, ArrowRight, Expand } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { SectionHeading } from './ui';

gsap.registerPlugin(ScrollTrigger);

const ITEMS = [
  { src: 'https://images.pexels.com/photos/29450016/pexels-photo-29450016.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', title: 'Luminous Geometry', tag: 'Real-time render', meta: '4K · Ray traced' },
  { src: 'https://images.pexels.com/photos/29703885/pexels-photo-29703885.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', title: 'Liquid Carbon', tag: 'Material study', meta: 'PBR · 8K maps' },
  { src: 'https://images.pexels.com/photos/30869729/pexels-photo-30869729.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', title: 'Aurum Sphere', tag: 'Client work', meta: 'Orbital campaign' },
  { src: 'https://images.pexels.com/photos/30869731/pexels-photo-30869731.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', title: 'Gold Framework', tag: 'Architecture', meta: 'Parametric' },
  { src: 'https://images.pexels.com/photos/10172055/pexels-photo-10172055.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', title: 'Silver Storm', tag: 'Simulation', meta: '120k particles' },
  { src: 'https://images.pexels.com/photos/29703884/pexels-photo-29703884.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', title: 'Spiral Bloom', tag: 'Generative', meta: 'Node graph' },
  { src: 'https://images.pexels.com/photos/30951901/pexels-photo-30951901.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', title: 'Chroma Shift', tag: 'Real-time render', meta: 'HDR pipeline' },
  { src: 'https://images.pexels.com/photos/33797646/pexels-photo-33797646.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', title: 'Soft Currents', tag: 'Motion study', meta: '240fps sim' },
];

export default function Gallery() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const [lightbox, setLightbox] = useState<number | null>(null);

  // Horizontal scroll on desktop only
  useLayoutEffect(() => {
    const mm = gsap.matchMedia();
    mm.add('(min-width: 1024px)', () => {
      const track = trackRef.current;
      const section = sectionRef.current;
      if (!track || !section) return;
      const getScroll = () => Math.max(0, track.scrollWidth - window.innerWidth + 64);
      const tween = gsap.to(track, {
        x: () => -getScroll(),
        ease: 'none',
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: () => `+=${getScroll()}`,
          pin: true,
          scrub: 1,
          anticipatePin: 1,
          invalidateOnRefresh: true,
        },
      });
      return () => {
        tween.scrollTrigger?.kill();
        tween.kill();
        gsap.set(track, { x: 0 });
      };
    });
    const onLoad = () => ScrollTrigger.refresh();
    window.addEventListener('load', onLoad);
    return () => {
      mm.revert();
      window.removeEventListener('load', onLoad);
    };
  }, []);

  const scrollBy = (dir: number) => {
    trackRef.current?.scrollBy({ left: dir * 380, behavior: 'smooth' });
  };

  // lightbox keyboard navigation
  useLayoutEffect(() => {
    if (lightbox === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setLightbox(null);
      if (e.key === 'ArrowRight') setLightbox((v) => (v === null ? v : (v + 1) % ITEMS.length));
      if (e.key === 'ArrowLeft') setLightbox((v) => (v === null ? v : (v + ITEMS.length - 1) % ITEMS.length));
    };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [lightbox]);

  return (
    <section id="gallery" ref={sectionRef} className="relative overflow-hidden bg-[#07070d] py-24 lg:h-screen lg:py-0">
      <div className="mx-auto flex h-full max-w-[1400px] flex-col justify-center px-5">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between lg:px-8">
          <SectionHeading
            align="left"
            eyebrow="Selected works"
            title="Worlds built with Aether"
            sub="A glimpse of what creators ship every day — rendered live, no post-production."
          />
          <div className="flex items-center gap-2.5">
            <button onClick={() => scrollBy(-1)} data-hover aria-label="Previous" className="glass flex h-11 w-11 items-center justify-center rounded-full text-white/70 transition hover:bg-white/10 hover:text-white lg:hidden">
              <ArrowLeft size={18} />
            </button>
            <button onClick={() => scrollBy(1)} data-hover aria-label="Next" className="glass flex h-11 w-11 items-center justify-center rounded-full text-white/70 transition hover:bg-white/10 hover:text-white lg:hidden">
              <ArrowRight size={18} />
            </button>
            <div className="hidden font-mono text-[10px] uppercase tracking-[0.3em] text-white/35 lg:block">Scroll to travel →</div>
          </div>
        </div>

        <div ref={trackRef} className="no-scrollbar mt-8 flex snap-x snap-mandatory gap-5 overflow-x-auto pb-4 lg:mt-10 lg:w-max lg:snap-none lg:overflow-visible lg:px-8 lg:pb-0">
          {ITEMS.map((it, i) => (
            <motion.figure
              key={it.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: Math.min(i * 0.05, 0.3) }}
              className="group relative w-[300px] shrink-0 snap-center overflow-hidden rounded-3xl border border-white/[0.08] md:w-[400px] lg:snap-align-none"
              data-hover
              onClick={() => setLightbox(i)}
            >
              <div className="relative h-[360px] overflow-hidden md:h-[400px]">
                <img
                  src={it.src}
                  alt={it.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
                <div className="absolute left-5 top-5 flex items-center gap-2">
                  <span className="glass rounded-full px-3.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.18em] text-white/85">{it.tag}</span>
                </div>
                <div className="absolute right-5 top-5 flex h-10 w-10 items-center justify-center rounded-full bg-black/50 text-white opacity-0 backdrop-blur-md transition-all duration-300 group-hover:opacity-100">
                  <Expand size={16} />
                </div>
                <figcaption className="absolute inset-x-0 bottom-0 p-6">
                  <div className="font-mono text-[10px] uppercase tracking-[0.22em] text-cyan-300/80">{it.meta}</div>
                  <div className="font-display mt-1.5 text-2xl font-semibold text-white">{it.title}</div>
                  <div className="mt-3 h-[2px] w-0 bg-gradient-to-r from-blue-400 to-cyan-300 transition-all duration-500 group-hover:w-full" />
                </figcaption>
              </div>
            </motion.figure>
          ))}
        </div>
      </div>

      {/* lightbox */}
      <AnimatePresence>
        {lightbox !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setLightbox(null)}
            className="fixed inset-0 z-[150] flex items-center justify-center bg-black/85 p-5 backdrop-blur-xl"
          >
            <motion.div
              initial={{ scale: 0.9, y: 24 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.92, y: 16 }}
              transition={{ type: 'spring', stiffness: 240, damping: 24 }}
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-4xl overflow-hidden rounded-3xl border border-white/10"
            >
              <img src={ITEMS[lightbox].src} alt={ITEMS[lightbox].title} className="max-h-[75vh] w-full object-cover" />
              <div className="flex items-center justify-between bg-[#0b0b14] p-5">
                <div>
                  <div className="font-display text-xl font-semibold text-white">{ITEMS[lightbox].title}</div>
                  <div className="font-mono text-[11px] uppercase tracking-widest text-white/40">{ITEMS[lightbox].tag} · {ITEMS[lightbox].meta}</div>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setLightbox((lightbox + ITEMS.length - 1) % ITEMS.length)} className="glass flex h-10 w-10 items-center justify-center rounded-full text-white/70 hover:text-white" aria-label="Previous"><ArrowLeft size={17} /></button>
                  <button onClick={() => setLightbox((lightbox + 1) % ITEMS.length)} className="glass flex h-10 w-10 items-center justify-center rounded-full text-white/70 hover:text-white" aria-label="Next"><ArrowRight size={17} /></button>
                  <button onClick={() => setLightbox(null)} className="rounded-full bg-white px-5 text-sm font-semibold text-black transition hover:bg-white/85">Close</button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
