import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, Star, Quote } from 'lucide-react';
import { SectionHeading } from './ui';

const ITEMS = [
  {
    quote: 'We replaced three tools with Aether. Our product configurator went from a six-week build to a single afternoon — and it runs at a locked 60fps on mobile.',
    name: 'Maya Chen',
    role: 'Head of 3D, Orbital',
    initials: 'MC',
    grad: 'linear-gradient(135deg,#4f7cff,#22d3ee)',
  },
  {
    quote: 'The first time I dragged a light around a live ray-traced scene in the browser, I just stared. This is the future of creative tooling, shipped today.',
    name: 'Jonas Weber',
    role: 'Creative Director, Parallax',
    initials: 'JW',
    grad: 'linear-gradient(135deg,#8b5cf6,#ec4899)',
  },
  {
    quote: 'Multiplayer editing in 3D sounded like a gimmick until our whole team reviewed a launch scene together. Comments pinned to geometry is genius.',
    name: 'Amara Okafor',
    role: 'Founder, Fluxworks',
    initials: 'AO',
    grad: 'linear-gradient(135deg,#22d3ee,#34d399)',
  },
  {
    quote: 'Enterprise security, edge deployment, analytics — Aether cleared our procurement review faster than any vendor we have ever evaluated. Flawless.',
    name: 'Daniel Roth',
    role: 'VP Engineering, Nimbus',
    initials: 'DR',
    grad: 'linear-gradient(135deg,#f59e0b,#ef4444)',
  },
];

export default function Testimonials() {
  const [idx, setIdx] = useState(0);
  const [dir, setDir] = useState(1);
  const [paused, setPaused] = useState(false);

  const go = (d: number) => {
    setDir(d);
    setIdx((p) => (p + d + ITEMS.length) % ITEMS.length);
  };

  useEffect(() => {
    if (paused) return;
    const t = setInterval(() => go(1), 6000);
    return () => clearInterval(t);
  }, [paused]);

  const item = ITEMS[idx];

  return (
    <section id="testimonials" className="relative overflow-hidden px-5 py-24 md:py-36">
      <div className="pointer-events-none absolute left-1/2 top-0 h-[400px] w-[700px] -translate-x-1/2 rounded-full bg-violet-700/10 blur-[140px]" />
      <div className="relative mx-auto max-w-4xl">
        <SectionHeading eyebrow="Loved worldwide" title="Creators can't stop talking" />

        <div
          className="relative mt-12 overflow-hidden rounded-[2rem] border border-white/[0.08] bg-white/[0.03] p-8 md:p-12"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
        >
          <Quote size={90} className="pointer-events-none absolute -right-3 -top-3 text-white/[0.04]" />
          <div className="flex gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star key={i} size={15} className="fill-amber-300 text-amber-300" />
            ))}
          </div>

          <div className="relative mt-6 min-h-[150px] md:min-h-[120px]">
            <AnimatePresence mode="wait" custom={dir}>
              <motion.blockquote
                key={idx}
                custom={dir}
                initial={{ opacity: 0, x: 60 * dir, filter: 'blur(6px)' }}
                animate={{ opacity: 1, x: 0, filter: 'blur(0px)' }}
                exit={{ opacity: 0, x: -60 * dir, filter: 'blur(6px)' }}
                transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
                className="font-display text-xl font-medium leading-relaxed text-white/90 md:text-2xl"
              >
                “{item.quote}”
              </motion.blockquote>
            </AnimatePresence>
          </div>

          <div className="mt-8 flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
            <AnimatePresence mode="wait">
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                className="flex items-center gap-4"
              >
                <div
                  className="font-display flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl text-base font-bold text-white"
                  style={{ background: item.grad, boxShadow: '0 8px 28px -8px rgba(0,0,0,.6)' }}
                >
                  {item.initials}
                </div>
                <div>
                  <div className="text-[15px] font-semibold text-white">{item.name}</div>
                  <div className="text-sm text-white/45">{item.role}</div>
                </div>
              </motion.div>
            </AnimatePresence>

            <div className="flex items-center gap-2.5">
              <button onClick={() => go(-1)} data-hover aria-label="Previous testimonial" className="glass flex h-11 w-11 items-center justify-center rounded-full text-white/70 transition hover:bg-white/10 hover:text-white active:scale-95">
                <ArrowLeft size={17} />
              </button>
              <button onClick={() => go(1)} data-hover aria-label="Next testimonial" className="glass flex h-11 w-11 items-center justify-center rounded-full text-white/70 transition hover:bg-white/10 hover:text-white active:scale-95">
                <ArrowRight size={17} />
              </button>
            </div>
          </div>

          {/* progress */}
          <div className="mt-8 flex gap-2">
            {ITEMS.map((_, i) => (
              <button key={i} onClick={() => { setDir(i > idx ? 1 : -1); setIdx(i); }} aria-label={`Go to ${i + 1}`} className="h-1 flex-1 overflow-hidden rounded-full bg-white/10" data-hover>
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-blue-400 to-cyan-300"
                  animate={{ width: i === idx ? '100%' : '0%' }}
                  transition={{ duration: i === idx ? 6 : 0.3, ease: 'linear' }}
                />
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
