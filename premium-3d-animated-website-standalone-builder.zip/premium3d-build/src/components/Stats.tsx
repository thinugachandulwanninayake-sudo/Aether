import { useEffect, useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { FadeUp } from './ui';

function Counter({ to, suffix = '', decimals = 0, duration = 1.8 }: { to: number; suffix?: string; decimals?: number; duration?: number }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });
  const [val, setVal] = useState(0);

  useEffect(() => {
    if (!inView) return;
    let raf: number;
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / (duration * 1000));
      const eased = 1 - Math.pow(1 - p, 4);
      setVal(to * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [inView, to, duration]);

  return (
    <span ref={ref}>
      {val.toFixed(decimals)}
      {suffix}
    </span>
  );
}

const STATS = [
  { value: 120, suffix: 'K+', label: 'Active creators', sub: 'Designers, devs & studios', w: '92%' },
  { value: 4.2, suffix: 'M', decimals: 1, label: 'Scenes rendered daily', sub: 'Across 140 countries', w: '78%' },
  { value: 99.99, suffix: '%', decimals: 2, label: 'Uptime SLA', sub: 'Enterprise edge network', w: '99%' },
  { value: 60, suffix: '', label: 'FPS locked', sub: 'On M1 and above', w: '85%' },
];

export default function Stats() {
  return (
    <section className="relative overflow-hidden px-5 py-24 md:py-32">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-indigo-950/[0.12] to-transparent" />
      <div className="relative mx-auto max-w-6xl">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STATS.map((s, i) => (
            <FadeUp key={s.label} delay={i * 0.08}>
              <div className="group relative overflow-hidden rounded-3xl border border-white/[0.07] bg-white/[0.03] p-8 transition-all duration-500 hover:border-violet-400/25 hover:bg-white/[0.05]">
                <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-violet-500/10 blur-2xl transition-all duration-500 group-hover:bg-violet-500/20" />
                <div className="font-display text-5xl font-bold text-white md:text-[3.4rem]">
                  <Counter to={s.value} suffix={s.suffix} decimals={s.decimals ?? 0} />
                </div>
                <div className="mt-2 text-sm font-semibold text-white/85">{s.label}</div>
                <div className="font-mono text-[10px] uppercase tracking-[0.18em] text-white/35">{s.sub}</div>
                <div className="mt-5 h-1 overflow-hidden rounded-full bg-white/[0.08]">
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: s.w }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.4, delay: 0.3 + i * 0.1, ease: [0.22, 1, 0.36, 1] }}
                    className="h-full rounded-full bg-gradient-to-r from-blue-500 via-violet-500 to-cyan-400"
                  />
                </div>
              </div>
            </FadeUp>
          ))}
        </div>
      </div>
    </section>
  );
}
