import { lazy, Suspense, useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Play, ChevronDown, MousePointer2 } from 'lucide-react';
import { Magnetic, GlowButton } from './ui';

const HeroScene = lazy(() => import('./HeroScene'));

function Word({ w, i, loaded }: { w: string; i: number; loaded: boolean }) {
  return (
    <span className="inline-block overflow-hidden pb-[0.1em] -mb-[0.1em]">
      <motion.span
        className="inline-block"
        initial={{ y: '115%', opacity: 0, filter: 'blur(10px)' }}
        animate={loaded ? { y: '0%', opacity: 1, filter: 'blur(0px)' } : {}}
        transition={{ duration: 1.1, delay: 0.35 + i * 0.09, ease: [0.22, 1, 0.36, 1] }}
      >
        {w}&nbsp;
      </motion.span>
    </span>
  );
}

export default function Hero({ loaded }: { loaded: boolean }) {
  const [scrollY, setScrollY] = useState(0);
  useEffect(() => {
    const f = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', f, { passive: true });
    return () => window.removeEventListener('scroll', f);
  }, []);

  const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  const fade = Math.max(0, 1 - scrollY / (window.innerHeight * 0.75));

  return (
    <section className="relative flex min-h-[100svh] flex-col overflow-hidden" id="top">
      {/* ambient bg */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_45%_at_50%_38%,rgba(99,102,241,0.16),transparent_70%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_40%_30%_at_72%_70%,rgba(34,211,238,0.08),transparent_70%)]" />
      <div className="grid-bg absolute inset-0 opacity-70" />

      {/* 3D canvas */}
      <div className="absolute inset-0" style={{ opacity: fade }}>
        <Suspense fallback={null}>
          {loaded && <HeroScene />}
        </Suspense>
      </div>

      {/* vignette + bottom blend */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_90%_70%_at_50%_50%,transparent_55%,rgba(5,5,7,0.55)_100%)]" />
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-[#050507] to-transparent" />

      {/* HUD side labels */}
      <motion.div
        initial={{ opacity: 0 }} animate={loaded ? { opacity: fade } : {}}
        className="absolute left-6 top-1/2 hidden -translate-y-1/2 xl:block"
      >
        <div className="flex flex-col items-center gap-4">
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-white/30 [writing-mode:vertical-rl]">Spatial Engine — v4.2</span>
          <div className="h-20 w-px bg-gradient-to-b from-transparent via-violet-400/50 to-transparent" />
          <MousePointer2 size={13} className="text-white/30" />
        </div>
      </motion.div>
      <motion.div
        initial={{ opacity: 0 }} animate={loaded ? { opacity: fade } : {}}
        className="absolute right-6 top-1/2 hidden -translate-y-1/2 xl:block"
      >
        <div className="flex flex-col items-center gap-4">
          <div className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse-glow" style={{ boxShadow: '0 0 12px #34d399' }} />
          <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-white/30 [writing-mode:vertical-rl]">Live render · 60 fps</span>
          <div className="h-20 w-px bg-gradient-to-b from-transparent via-cyan-400/50 to-transparent" />
        </div>
      </motion.div>

      {/* content */}
      <div className="relative z-10 mx-auto flex w-full max-w-6xl flex-1 flex-col items-center justify-center px-5 pt-32 text-center" style={{ opacity: fade, transform: `translateY(${scrollY * 0.18}px)` }}>
        <motion.div
          initial={{ opacity: 0, y: 18, scale: 0.95 }}
          animate={loaded ? { opacity: 1, y: 0, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.25 }}
        >
          <button onClick={() => go('showcase')} data-hover className="group glass inline-flex items-center gap-2.5 rounded-full py-1.5 pl-2 pr-4 text-xs text-white/75 transition hover:border-violet-400/40">
            <span className="rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-widest text-white" style={{ background: 'linear-gradient(135deg,#4f7cff,#8b5cf6)' }}>New</span>
            Aether Engine 4.2 — Neural physics is live
            <ArrowRight size={13} className="transition-transform duration-300 group-hover:translate-x-1" />
          </button>
        </motion.div>

        <h1 className="font-display mt-7 text-[11vw] font-bold leading-[0.98] tracking-tight sm:text-7xl md:text-8xl lg:text-[7.5rem]">
          {['SCULPT', 'REALITY'].map((w, i) => (
            <Word key={w} w={w} i={i} loaded={loaded} />
          ))}
          <br />
          <span className="text-gradient">
            {['IN', 'REAL', 'TIME.'].map((w, i) => (
              <Word key={w} w={w} i={i + 2} loaded={loaded} />
            ))}
          </span>
        </h1>

        <motion.p
          initial={{ opacity: 0, y: 20, filter: 'blur(6px)' }}
          animate={loaded ? { opacity: 1, y: 0, filter: 'blur(0px)' } : {}}
          transition={{ duration: 1, delay: 0.9 }}
          className="mt-6 max-w-xl text-balance text-[15px] leading-relaxed text-white/60 md:text-lg"
        >
          The spatial computing platform for designing cinematic 3D worlds.
          Model, simulate and ship immersive experiences — all in the browser, all in real time.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={loaded ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 1, delay: 1.05 }}
          className="mt-9 flex flex-col items-center gap-4 sm:flex-row"
        >
          <GlowButton onClick={() => go('cta')}>
            Start creating free <ArrowRight size={16} className="transition-transform duration-300 group-hover:translate-x-1" />
          </GlowButton>
          <GlowButton variant="ghost" onClick={() => go('showcase')}>
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-white/10">
              <Play size={11} className="ml-0.5 fill-white" />
            </span>
            Watch the engine
          </GlowButton>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={loaded ? { opacity: 1 } : {}}
          transition={{ delay: 1.4, duration: 1 }}
          className="mt-10 flex items-center gap-5 font-mono text-[10px] uppercase tracking-[0.22em] text-white/35"
        >
          <span>WebGL2</span><span className="h-1 w-1 rounded-full bg-white/20" />
          <span>120k+ creators</span><span className="h-1 w-1 rounded-full bg-white/20" />
          <span>No install</span>
        </motion.div>
      </div>

      {/* scroll cue */}
      <motion.button
        onClick={() => go('intro')}
        initial={{ opacity: 0 }}
        animate={loaded ? { opacity: fade } : {}}
        transition={{ delay: 1.6 }}
        className="relative z-10 mx-auto mb-8 flex flex-col items-center gap-2 text-white/40 transition hover:text-white"
        aria-label="Scroll down"
      >
        <span className="font-mono text-[10px] uppercase tracking-[0.3em]">Scroll</span>
        <motion.span animate={{ y: [0, 7, 0] }} transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}>
          <ChevronDown size={18} />
        </motion.span>
      </motion.button>

      {/* logo marquee */}
      <div className="relative z-10 border-t border-white/[0.06] bg-black/30 py-4 backdrop-blur-md">
        <div className="mask-fade-x overflow-hidden">
          <div className="animate-marquee flex w-max items-center gap-14 pr-14 font-mono text-[11px] uppercase tracking-[0.28em] text-white/30">
            {[0, 1].map((k) => (
              <div key={k} className="flex items-center gap-14">
                {['Vertex Studios', 'Orbital', 'Hexalab', 'Polyform', 'Nimbus', 'Kinetic', 'Parallax', 'Fluxworks'].map((b) => (
                  <span key={b} className="flex items-center gap-14">
                    <Magnetic strength={8}><span className="transition hover:text-white/70" data-hover>{b}</span></Magnetic>
                    <span className="h-1 w-1 rounded-full bg-violet-400/40" />
                  </span>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
