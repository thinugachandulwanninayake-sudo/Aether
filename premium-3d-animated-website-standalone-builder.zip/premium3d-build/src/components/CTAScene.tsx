import { Suspense, useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Environment, Lightformer } from '@react-three/drei';
import * as THREE from 'three';

function Knot() {
  const m = useRef<THREE.Mesh>(null);
  const w = useRef<THREE.Mesh>(null);
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (m.current) {
      m.current.rotation.y = t * 0.3;
      m.current.rotation.x = Math.sin(t * 0.2) * 0.4;
      m.current.position.y = Math.sin(t * 0.8) * 0.15;
      m.current.rotation.z += (state.pointer.x * 0.4 - m.current.rotation.z) * 0.04;
    }
    if (w.current) {
      w.current.rotation.y = -t * 0.18;
      w.current.rotation.x = t * 0.1;
    }
  });
  return (
    <group>
      <mesh ref={m}>
        <torusKnotGeometry args={[1, 0.3, 200, 32]} />
        <meshPhysicalMaterial
          color="#0c0c1a" metalness={0.3} roughness={0.1}
          transmission={0.95} thickness={1.5} ior={1.45}
          clearcoat={1} iridescence={0.6} envMapIntensity={1.7}
        />
      </mesh>
      <mesh ref={w} scale={1.02}>
        <torusKnotGeometry args={[1, 0.31, 80, 12]} />
        <meshBasicMaterial color="#8b5cf6" wireframe transparent opacity={0.16} />
      </mesh>
      <mesh rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[2.3, 0.008, 8, 160]} />
        <meshBasicMaterial color="#22d3ee" transparent opacity={0.4} />
      </mesh>
    </group>
  );
}

export default function CTAScene() {
  return (
    <Canvas dpr={[1, 1.6]} camera={{ position: [0, 0, 5.4], fov: 42 }} gl={{ antialias: true, alpha: true }}>
      <Suspense fallback={null}>
        <ambientLight intensity={0.3} />
        <pointLight position={[5, 3, 4]} intensity={10} color="#8b5cf6" distance={16} />
        <pointLight position={[-5, -2, 3]} intensity={8} color="#22d3ee" distance={16} />
        <Knot />
        <Environment resolution={128}>
          <group rotation={[-Math.PI / 3, 0, 0]}>
            <Lightformer form="circle" intensity={4} position={[0, 5, -9]} scale={2} color="#aebaff" />
            <Lightformer intensity={2} rotation-y={Math.PI / 2} position={[-5, 1, -1]} scale={[20, 0.6, 1]} color="#22d3ee" />
            <Lightformer intensity={2} rotation-y={-Math.PI / 2} position={[5, 1, 0]} scale={[20, 0.8, 1]} color="#8b5cf6" />
          </group>
        </Environment>
      </Suspense>
    </Canvas>
  );
}
