import { ArrowUp, Globe, AtSign, Send, Rss } from 'lucide-react';

const COLS = [
  { h: 'Platform', links: ['Spatial Engine', 'Neural Physics', 'Material Lab', 'Aether Cloud', 'Changelog'] },
  { h: 'Resources', links: ['Documentation', 'Tutorials', 'Community', 'Showcase', 'Status'] },
  { h: 'Company', links: ['About', 'Careers', 'Press kit', 'Contact', 'Legal'] },
];

export default function Footer() {
  const go = (id: string) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <footer className="relative overflow-hidden border-t border-white/[0.07] px-5 pb-10 pt-16 md:pt-20">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-violet-400/60 to-transparent" />
      <div className="pointer-events-none absolute left-1/2 top-10 h-64 w-[700px] -translate-x-1/2 rounded-full bg-violet-700/[0.08] blur-[120px]" />

      <div className="relative mx-auto max-w-6xl">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_2fr]">
          <div>
            <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-2.5" data-hover>
              <div className="flex h-10 w-10 items-center justify-center rounded-xl" style={{ background: 'linear-gradient(135deg,#4f7cff,#8b5cf6 60%,#22d3ee)' }}>
                <svg width="19" height="19" viewBox="0 0 24 24" fill="none">
                  <path d="M12 2L22 12L12 22L2 12L12 2Z" stroke="white" strokeWidth="1.8" />
                  <circle cx="12" cy="12" r="3.2" fill="white" />
                </svg>
              </div>
              <span className="font-display text-base font-bold tracking-[0.3em] text-white">AETHER</span>
            </button>
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-white/45">
              The spatial computing platform for the next era of the web. Designed in orbit, built for Earth.
            </p>
            <div className="mt-6 flex gap-2.5">
              {[Globe, AtSign, Send, Rss].map((I, i) => (
                <a
                  key={i}
                  href="#top"
                  onClick={(e) => e.preventDefault()}
                  aria-label="Social link"
                  data-hover
                  className="glass flex h-10 w-10 items-center justify-center rounded-full text-white/55 transition-all duration-300 hover:-translate-y-1 hover:border-violet-400/40 hover:text-white"
                >
                  <I size={16} />
                </a>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            {COLS.map((c) => (
              <div key={c.h}>
                <div className="font-mono text-[10px] uppercase tracking-[0.28em] text-white/35">{c.h}</div>
                <ul className="mt-4 space-y-3">
                  {c.links.map((l) => (
                    <li key={l}>
                      <button onClick={() => go('features')} data-hover className="link-underline text-sm text-white/60 transition hover:text-white">
                        {l}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-5 border-t border-white/[0.07] pt-7 sm:flex-row">
          <div className="font-mono text-[11px] uppercase tracking-[0.18em] text-white/30">
            © 2026 Aether Labs, Inc. — Crafted in WebGL
          </div>

          <div className="creator-credit order-last flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.16em] text-white/30 sm:order-none">
            <span>Website created by</span>
            <span className="group relative inline-flex items-center font-semibold tracking-[0.14em] text-gradient">
              Thinuga Wanninayake
              <span className="absolute -bottom-1 left-0 h-px w-0 bg-gradient-to-r from-blue-400 via-violet-400 to-cyan-300 transition-all duration-500 group-hover:w-full" />
            </span>
          </div>
          <div className="flex items-center gap-5 font-mono text-[11px] uppercase tracking-[0.18em] text-white/30">
            <button onClick={() => go('top')} className="transition hover:text-white" data-hover>Privacy</button>
            <button onClick={() => go('top')} className="transition hover:text-white" data-hover>Terms</button>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              data-hover
              aria-label="Back to top"
              className="group flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-white/60 transition hover:border-violet-400/50 hover:text-white"
            >
              <ArrowUp size={16} className="transition-transform duration-300 group-hover:-translate-y-0.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
