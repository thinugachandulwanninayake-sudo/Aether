import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

export default function Loader({ onDone }: { onDone: () => void }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let raf: number;
    const start = performance.now();
    const dur = 1900;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setCount(Math.round(eased * 100));
      if (p < 1) raf = requestAnimationFrame(tick);
      else setTimeout(onDone, 350);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [onDone]);

  return (
    <motion.div
      className="fixed inset-0 z-[200] flex flex-col items-center justify-center bg-[#050507]"
      exit={{ y: '-100%', transition: { duration: 0.9, ease: [0.76, 0, 0.24, 1] } }}
    >
      <div className="grid-bg absolute inset-0" />
      <div className="absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet-600/15 blur-[120px]" />
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative flex items-center gap-3"
      >
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl"
          style={{ background: 'linear-gradient(135deg,#4f7cff,#8b5cf6 60%,#22d3ee)', boxShadow: '0 0 40px rgba(124,92,255,.5)' }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <path d="M12 2L22 12L12 22L2 12L12 2Z" stroke="white" strokeWidth="1.6" />
            <circle cx="12" cy="12" r="3.2" fill="white" />
          </svg>
        </div>
        <span className="font-display text-2xl font-bold tracking-[0.28em] text-white">AETHER</span>
      </motion.div>

      <div className="relative mt-10 h-[2px] w-56 overflow-hidden rounded-full bg-white/10">
        <motion.div
          className="h-full rounded-full"
          style={{ background: 'linear-gradient(90deg,#4f7cff,#8b5cf6,#22d3ee)', width: `${count}%` }}
        />
      </div>
      <div className="mt-4 flex w-56 items-center justify-between font-mono text-[11px] uppercase tracking-[0.2em] text-white/40">
        <span>Initializing scene</span>
        <span className="text-white/80">{count}%</span>
      </div>
    </motion.div>
  );
}
