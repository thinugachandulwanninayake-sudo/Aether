import { Cpu, Globe, Layers, Zap, Users, ShieldCheck, ArrowUpRight } from 'lucide-react';
import { SectionHeading, TiltCard, FadeUp } from './ui';

const FEATURES = [
  {
    icon: Zap,
    title: 'Real-time ray tracing',
    desc: 'Hardware-accelerated global illumination, reflections and soft shadows — rendered live at 60fps in any modern browser.',
    span: 'md:col-span-2',
    accent: 'from-blue-500/25 to-transparent',
  },
  {
    icon: Cpu,
    title: 'Neural physics',
    desc: 'GPU rigid-bodies, cloth and fluids simulated 4× faster than CPU engines.',
    span: '',
    accent: 'from-violet-500/25 to-transparent',
  },
  {
    icon: Layers,
    title: 'Material lab',
    desc: 'Procedural PBR authoring with 400+ parametric presets.',
    span: '',
    accent: 'from-cyan-500/25 to-transparent',
  },
  {
    icon: Users,
    title: 'Multiplayer editing',
    desc: 'Invite your team into the same 3D scene. Cursors, comments and version history built in.',
    span: '',
    accent: 'from-fuchsia-500/25 to-transparent',
  },
  {
    icon: Globe,
    title: 'One-link deploy',
    desc: 'Publish to a global edge network. Your world loads in under 2 seconds, anywhere on Earth.',
    span: '',
    accent: 'from-indigo-500/25 to-transparent',
  },
  {
    icon: ShieldCheck,
    title: 'Enterprise grade',
    desc: 'SOC2, SSO and private workspaces. Your IP stays yours — encrypted at rest and in transit.',
    span: 'md:col-span-2',
    accent: 'from-emerald-500/20 to-transparent',
  },
];

export default function Features() {
  return (
    <section id="features" className="relative px-5 py-24 md:py-36">
      <div className="pointer-events-none absolute left-1/2 top-1/2 h-[600px] w-[900px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-700/[0.07] blur-[150px]" />
      <div className="relative mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="Capabilities"
          title="An engine that feels like magic"
          sub="Everything you need to design, simulate and ship spatial experiences — unified in one fluid workflow."
        />

        <div className="mt-14 grid grid-cols-1 gap-4 md:grid-cols-4">
          {FEATURES.map((f, i) => (
            <FadeUp key={f.title} delay={(i % 4) * 0.08} className={f.span}>
              <TiltCard max={7} className="group h-full overflow-hidden rounded-3xl border border-white/[0.07] bg-white/[0.03] p-7 transition-colors duration-500 hover:border-white/[0.16] md:p-8">
                <div className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${f.accent} opacity-0 transition-opacity duration-500 group-hover:opacity-100`} />
                <div className="relative">
                  <div className="flex items-start justify-between">
                    <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500/25 to-cyan-400/10 text-cyan-200 ring-1 ring-white/10 transition-transform duration-500 group-hover:scale-110 group-hover:rotate-3">
                      <f.icon size={21} />
                    </div>
                    <ArrowUpRight size={17} className="text-white/20 transition-all duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 group-hover:text-white/70" />
                  </div>
                  <h3 className="font-display mt-6 text-xl font-semibold text-white">{f.title}</h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-white/50">{f.desc}</p>
                </div>
              </TiltCard>
            </FadeUp>
          ))}
        </div>
      </div>
    </section>
  );
}
