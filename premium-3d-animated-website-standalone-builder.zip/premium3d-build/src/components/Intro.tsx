import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { RevealText, FadeUp } from './ui';

export default function Intro() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 0.85', 'end 0.4'] });
  const y1 = useTransform(scrollYProgress, [0, 1], [60, -60]);
  const y2 = useTransform(scrollYProgress, [0, 1], [120, -120]);
  const rotate = useTransform(scrollYProgress, [0, 1], [0, 90]);

  return (
    <section id="intro" ref={ref} className="relative overflow-hidden px-5 py-28 md:py-40">
      {/* ambient */}
      <div className="pointer-events-none absolute left-1/2 top-0 h-[500px] w-[800px] -translate-x-1/2 rounded-full bg-violet-700/10 blur-[140px]" />
      <motion.div style={{ y: y1 }} className="pointer-events-none absolute -left-24 top-1/3 h-72 w-72 rounded-full border border-white/[0.06]" />
      <motion.div style={{ y: y2 }} className="pointer-events-none absolute -right-20 top-1/4 h-96 w-96 rounded-full border border-white/[0.05]">
        <motion.div style={{ rotate }} className="absolute inset-8 rounded-full border border-dashed border-violet-400/20" />
      </motion.div>

      <div className="relative mx-auto max-w-5xl text-center">
        <FadeUp>
          <div className="font-mono text-[11px] uppercase tracking-[0.35em] text-cyan-300/80">The manifesto</div>
        </FadeUp>
        <div className="font-display mt-6 text-3xl font-medium leading-[1.25] tracking-tight text-white/90 md:text-5xl lg:text-[3.4rem]">
          <RevealText text="The web is flat. Your ideas are not." delay={0.05} />
          <br />
          <span className="text-white/35">
            <RevealText text="Aether turns browsers into" delay={0.3} />
          </span>{' '}
          <span className="text-gradient-blue">
            <RevealText text="cinematic dimensions" delay={0.5} />
          </span>
          <span className="text-white/35">
            <RevealText text="— no installs, no compromises." delay={0.65} />
          </span>
        </div>
        <FadeUp delay={0.4}>
          <p className="mx-auto mt-8 max-w-2xl text-base leading-relaxed text-white/50 md:text-lg">
            One platform for real-time rendering, physics and collaboration. Prototype in minutes,
            present in the browser, and deploy to millions of devices with a single link.
          </p>
        </FadeUp>

        {/* mini feature strip */}
        <div className="mt-14 grid grid-cols-2 gap-3 md:grid-cols-4">
          {[
            { k: '60 fps', v: 'Locked render loop' },
            { k: '8 ms', v: 'Input latency' },
            { k: '4K', v: 'HDR pipeline' },
            { k: '∞', v: 'Creative canvas' },
          ].map((s, i) => (
            <FadeUp key={s.v} delay={0.1 * i}>
              <div className="glass group rounded-2xl px-4 py-6 transition-all duration-500 hover:border-violet-400/30 hover:bg-white/[0.06]">
                <div className="font-display text-3xl font-bold text-white transition group-hover:scale-105">{s.k}</div>
                <div className="mt-1 font-mono text-[10px] uppercase tracking-[0.2em] text-white/40">{s.v}</div>
              </div>
            </FadeUp>
          ))}
        </div>
      </div>
    </section>
  );
}
