import { useRef, useState, useEffect } from 'react';
import { motion, useScroll, AnimatePresence } from 'framer-motion';
import { PenTool, Atom, Rocket, Check } from 'lucide-react';
import { SectionHeading, FadeUp } from './ui';

const STEPS = [
  {
    icon: PenTool,
    n: '01',
    title: 'Design in flow',
    desc: 'Sketch, model and light your scene with an interface that stays out of your way. Import from Blender, Figma or start from 400+ parametric primitives.',
    points: ['Drag-and-drop scene graph', 'Live PBR material editor', 'Figma & Blender bridge'],
    color: '#4f7cff',
  },
  {
    icon: Atom,
    n: '02',
    title: 'Simulate everything',
    desc: 'Add physics, particles and cinematic cameras. The neural solver previews every frame in real time — what you see is what ships.',
    points: ['GPU physics solver', 'Volumetric lighting', 'Keyframe + procedural motion'],
    color: '#8b5cf6',
  },
  {
    icon: Rocket,
    n: '03',
    title: 'Ship with a link',
    desc: 'Publish to the edge network in one click. Embed anywhere, track engagement, and push updates live without re-deploying.',
    points: ['Global edge CDN', 'Analytics built-in', 'Versioned releases'],
    color: '#22d3ee',
  },
];

export default function HowItWorks() {
  const ref = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(0);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start 0.6', 'end 0.6'] });

  useEffect(() => {
    const unsub = scrollYProgress.on('change', (v) => {
      const idx = Math.min(2, Math.max(0, Math.floor(v * 3)));
      setActive(idx);
    });
    return unsub;
  }, [scrollYProgress]);

  return (
    <section id="process" ref={ref} className="relative px-5 py-24 md:py-36">
      <div className="pointer-events-none absolute left-0 top-1/3 h-[500px] w-[400px] rounded-full bg-violet-700/10 blur-[140px]" />
      <div className="relative mx-auto max-w-6xl">
        <SectionHeading
          eyebrow="How it works"
          title="From idea to immersive in three moves"
          sub="A workflow designed for velocity — loved by solo creators and world-class studios alike."
        />

        <div className="mt-16 grid gap-10 lg:grid-cols-2 lg:gap-16">
          {/* left: sticky visual */}
          <div className="relative hidden lg:block">
            <div className="sticky top-32 overflow-hidden rounded-[2rem] border border-white/[0.08] bg-[#0a0a13]">
              <div className="grid-bg absolute inset-0" />
              <div className="relative flex h-[520px] flex-col items-center justify-center p-10">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={active}
                    initial={{ opacity: 0, scale: 0.85, rotateY: -18 }}
                    animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                    exit={{ opacity: 0, scale: 0.9, rotateY: 18 }}
                    transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
                    className="flex flex-col items-center text-center"
                  >
                    <div
                      className="font-display text-[7rem] font-bold leading-none"
                      style={{ color: 'transparent', WebkitTextStroke: `1.5px ${STEPS[active].color}66` }}
                    >
                      {STEPS[active].n}
                    </div>
                    <div
                      className="mt-4 flex h-20 w-20 items-center justify-center rounded-3xl"
                      style={{ background: `${STEPS[active].color}1f`, boxShadow: `0 0 60px ${STEPS[active].color}44`, border: `1px solid ${STEPS[active].color}55` }}
                    >
                      {(() => {
                        const I = STEPS[active].icon;
                        return <I size={34} style={{ color: STEPS[active].color }} />;
                      })()}
                    </div>
                    <div className="font-display mt-6 text-3xl font-semibold text-white">{STEPS[active].title}</div>
                    {/* progress dots */}
                    <div className="mt-8 flex gap-2.5">
                      {STEPS.map((_, i) => (
                        <div key={i} className="h-1.5 w-10 overflow-hidden rounded-full bg-white/10">
                          <motion.div
                            className="h-full rounded-full"
                            style={{ background: STEPS[active].color }}
                            animate={{ width: i <= active ? '100%' : '0%' }}
                            transition={{ duration: 0.5 }}
                          />
                        </div>
                      ))}
                    </div>
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </div>

          {/* right: steps */}
          <div className="flex flex-col gap-6">
            {STEPS.map((s, i) => (
              <FadeUp key={s.n} delay={0.05}>
                <div
                  onMouseEnter={() => setActive(i)}
                  className={`group rounded-[1.75rem] border p-8 transition-all duration-500 md:p-10 ${
                    active === i
                      ? 'border-white/[0.16] bg-white/[0.05]'
                      : 'border-white/[0.07] bg-white/[0.02]'
                  }`}
                  style={active === i ? { boxShadow: `0 20px 80px -20px ${s.color}33` } : {}}
                  data-hover
                >
                  <div className="flex items-center gap-4">
                    <div
                      className="flex h-12 w-12 items-center justify-center rounded-2xl transition-transform duration-500 group-hover:scale-110"
                      style={{ background: `${s.color}1c`, border: `1px solid ${s.color}44` }}
                    >
                      <s.icon size={20} style={{ color: s.color }} />
                    </div>
                    <span className="font-mono text-xs uppercase tracking-[0.3em] text-white/35">Step {s.n}</span>
                  </div>
                  <h3 className="font-display mt-5 text-2xl font-semibold text-white md:text-3xl">{s.title}</h3>
                  <p className="mt-3 text-[15px] leading-relaxed text-white/55">{s.desc}</p>
                  <ul className="mt-6 space-y-2.5">
                    {s.points.map((p) => (
                      <li key={p} className="flex items-center gap-3 text-sm text-white/70">
                        <span className="flex h-5 w-5 items-center justify-center rounded-full" style={{ background: `${s.color}22` }}>
                          <Check size={12} style={{ color: s.color }} />
                        </span>
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>
              </FadeUp>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
