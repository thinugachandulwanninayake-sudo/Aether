import { lazy, Suspense, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowRight, CheckCircle2, Mail, AlertCircle, Sparkles } from 'lucide-react';
import { RevealText, FadeUp, Magnetic } from './ui';

const CTAScene = lazy(() => import('./CTAScene'));

export default function CTA() {
  const [email, setEmail] = useState('');
  const [state, setState] = useState<'idle' | 'error' | 'loading' | 'done'>('idle');

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setState('error');
      return;
    }
    setState('loading');
    setTimeout(() => setState('done'), 1200);
  };

  return (
    <section id="cta" className="relative px-5 py-24 md:py-36">
      <div className="relative mx-auto max-w-6xl overflow-hidden rounded-[2.5rem] border border-white/[0.09]">
        {/* bg layers */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#0c0c1c] via-[#0a0a16] to-[#06121a]" />
        <div className="grid-bg absolute inset-0 opacity-50" />
        <div className="absolute -left-24 -top-24 h-96 w-96 rounded-full bg-violet-600/20 blur-[120px]" />
        <div className="absolute -bottom-24 -right-24 h-96 w-96 rounded-full bg-cyan-500/15 blur-[120px]" />

        <div className="relative grid lg:grid-cols-2">
          {/* left copy + form */}
          <div className="p-8 md:p-14 lg:p-16">
            <FadeUp>
              <div className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 font-mono text-[10px] uppercase tracking-[0.22em] text-cyan-200">
                <Sparkles size={12} /> Early access — Season 04
              </div>
            </FadeUp>
            <RevealText
              text="Step inside your next dimension."
              as="h2"
              className="font-display mt-5 text-4xl font-semibold leading-[1.05] tracking-tight text-white md:text-5xl"
            />
            <FadeUp delay={0.2}>
              <p className="mt-4 max-w-md text-[15px] leading-relaxed text-white/55">
                Join 120,000+ creators building the spatial web. Free to start — no credit card, no install. Just your browser and your imagination.
              </p>
            </FadeUp>

            <FadeUp delay={0.3}>
              <AnimatePresence mode="wait">
                {state === 'done' ? (
                  <motion.div
                    key="done"
                    initial={{ opacity: 0, scale: 0.94 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="mt-8 flex items-center gap-4 rounded-2xl border border-emerald-400/25 bg-emerald-400/[0.08] p-5"
                  >
                    <CheckCircle2 size={28} className="shrink-0 text-emerald-300" />
                    <div>
                      <div className="font-semibold text-white">You're on the list!</div>
                      <div className="text-sm text-white/55">Invite heading to <span className="text-white">{email}</span> — check your inbox.</div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.form key="form" exit={{ opacity: 0, y: -10 }} onSubmit={submit} className="mt-8" noValidate>
                    <div className="flex flex-col gap-3 sm:flex-row">
                      <div className="relative flex-1">
                        <Mail size={16} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
                        <input
                          type="email"
                          value={email}
                          onChange={(e) => { setEmail(e.target.value); if (state === 'error') setState('idle'); }}
                          placeholder="you@studio.com"
                          className={`w-full rounded-full border bg-white/[0.05] py-4 pl-11 pr-5 text-sm text-white placeholder:text-white/30 outline-none backdrop-blur-md transition-all duration-300 focus:bg-white/[0.08] ${
                            state === 'error' ? 'border-red-400/60' : 'border-white/12 focus:border-violet-400/60'
                          }`}
                        />
                      </div>
                      <Magnetic strength={14}>
                        <button
                          type="submit"
                          disabled={state === 'loading'}
                          className="group flex items-center justify-center gap-2 rounded-full px-7 py-4 text-sm font-semibold text-white transition active:scale-95 disabled:opacity-70"
                          style={{ background: 'linear-gradient(135deg,#4f7cff,#8b5cf6 60%,#22d3ee)', boxShadow: '0 8px 36px -8px rgba(99,102,241,.7)' }}
                        >
                          {state === 'loading' ? (
                            <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/40 border-t-white" />
                          ) : (
                            <>Get access <ArrowRight size={16} className="transition-transform duration-300 group-hover:translate-x-1" /></>
                          )}
                        </button>
                      </Magnetic>
                    </div>
                    <AnimatePresence>
                      {state === 'error' && (
                        <motion.p initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-3 flex items-center gap-2 text-[13px] text-red-300">
                          <AlertCircle size={14} /> Please enter a valid email address.
                        </motion.p>
                      )}
                    </AnimatePresence>
                    <p className="mt-4 font-mono text-[10px] uppercase tracking-[0.2em] text-white/30">
                      Free tier · Cancel anytime · SOC2 compliant
                    </p>
                  </motion.form>
                )}
              </AnimatePresence>
            </FadeUp>
          </div>

          {/* right 3D */}
          <div className="relative min-h-[340px] lg:min-h-[560px]">
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_60%_at_50%_50%,rgba(139,92,246,0.16),transparent_70%)]" />
            <Suspense fallback={<div className="flex h-full items-center justify-center"><div className="h-10 w-10 animate-spin rounded-full border-2 border-violet-400/30 border-t-violet-400" /></div>}>
              <CTAScene />
            </Suspense>
            <div className="absolute bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full bg-black/50 px-4 py-2 font-mono text-[10px] uppercase tracking-[0.22em] text-white/50 backdrop-blur-md">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-300 animate-pulse-glow" /> Rendering live
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
