#!/bin/bash
set -e
cd "$(dirname "$0")"
echo "========================================"
echo " Premium 3D Website - Standalone Builder"
echo "========================================"
echo
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Node.js is required. Install the LTS version from https://nodejs.org/ then run this file again."
  read -r -p "Press Return to close..."
  exit 1
fi
if [ ! -d node_modules ]; then
  echo "Installing website dependencies (requires internet on the first run)..."
  npm install
fi
echo
npm run build
echo
echo "Build complete. Open dist/index.html to view the standalone website."
read -r -p "Press Return to close..."
